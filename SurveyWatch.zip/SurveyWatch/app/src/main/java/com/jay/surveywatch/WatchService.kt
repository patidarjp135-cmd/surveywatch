package com.jay.surveywatch

import android.accessibilityservice.AccessibilityService
import android.app.*
import android.content.Context
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

object Notifier {
    fun post(ctx: Context, title: String, text: String) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("surveys", "New surveys", NotificationManager.IMPORTANCE_HIGH))
        val pkg = ctx.getSharedPreferences("p", 0).getString("pkg", null)
        val launch = pkg?.let { ctx.packageManager.getLaunchIntentForPackage(it) }
        val pi = launch?.let { PendingIntent.getActivity(ctx, 0, it, PendingIntent.FLAG_IMMUTABLE) }
        nm.notify(System.currentTimeMillis().toInt(),
            Notification.Builder(ctx, "surveys")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title).setContentText(text)
                .setContentIntent(pi).setAutoCancel(true).build())
    }
}

class WatchService : AccessibilityService() {
    private val reward = Regex("""([$₹€£]\s?\d+([.,]\d+)?|\d+([.,]\d+)?\s?USD)""", RegexOption.IGNORE_CASE)
    private val duration = Regex("""\d+\s?(min|mins|minutes)\b""", RegexOption.IGNORE_CASE)
    private var last = 0L

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val prefs = getSharedPreferences("p", 0)
        val pkg = prefs.getString("pkg", null) ?: return
        if (e.packageName?.toString() != pkg) return
        val now = SystemClock.elapsedRealtime()
        if (now - last < 1500) return
        last = now
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != pkg) return

        val found = linkedSetOf<String>()
        walk(root, found, 0)
        if (found.isEmpty()) return

        val seen = prefs.getStringSet("seen", emptySet())!!.toMutableSet()
        val learning = System.currentTimeMillis() < prefs.getLong("learnUntil", 0) || seen.isEmpty()
        val fresh = found.filter { it !in seen }
        if (fresh.isEmpty()) return
        seen.addAll(fresh)
        prefs.edit().putStringSet("seen", seen).apply()
        if (!learning) {
            Notifier.post(this, "New survey" + if (fresh.size > 1) "s (${fresh.size})" else "",
                fresh.first().replace("|", " · "))
        }
    }

    // Returns all text under node; records a key (reward|duration) for the smallest node that has both.
    private fun walk(n: AccessibilityNodeInfo?, out: MutableSet<String>, depth: Int): String {
        if (n == null || depth > 40) return ""
        val sb = StringBuilder()
        n.text?.let { sb.append(it).append(' ') }
        n.contentDescription?.let { sb.append(it).append(' ') }
        var childMatched = false
        for (i in 0 until n.childCount) {
            val c = n.getChild(i)
            val t = walk(c, out, depth + 1)
            if (isCard(t)) childMatched = true
            sb.append(t)
            c?.recycle()
        }
        val full = sb.toString()
        if (!childMatched && isCard(full)) {
            out.add(reward.find(full)!!.value.replace(" ", "") + "|" + duration.find(full)!!.value.replace(" ", ""))
        }
        return full
    }

    private fun isCard(t: String) = t.isNotEmpty() && reward.containsMatchIn(t) && duration.containsMatchIn(t)
}
