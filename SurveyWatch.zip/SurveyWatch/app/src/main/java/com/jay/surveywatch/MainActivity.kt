package com.jay.surveywatch

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("p", 0)
        val d = resources.displayMetrics.density
        val pm = packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .distinctBy { it.second }.sortedBy { it.first.lowercase() }

        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, apps.map { it.first })
            setSelection(apps.indexOfFirst { it.second == prefs.getString("pkg", "") }.coerceAtLeast(0))
        }
        fun btn(label: String, f: (View) -> Unit) = Button(this).apply { text = label; setOnClickListener(f) }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding((24 * d).toInt(), 0, (24 * d).toInt(), 0)
        }
        root.addView(TextView(this).apply { text = "Survey Watch"; textSize = 26f; gravity = Gravity.CENTER })
        root.addView(TextView(this).apply { text = "1. Pick your survey app"; setPadding(0, (16 * d).toInt(), 0, 0) })
        root.addView(spinner)
        root.addView(btn("Save app") {
            prefs.edit().putString("pkg", apps[spinner.selectedItemPosition].second).apply()
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        })
        root.addView(TextView(this).apply { text = "2. Turn on Survey Watch in Accessibility" })
        root.addView(btn("Open accessibility settings") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(TextView(this).apply { text = "3. Open the survey app's Surveys tab, scroll the list, and press this" })
        root.addView(btn("Learn current surveys (60 s)") {
            prefs.edit().putLong("learnUntil", System.currentTimeMillis() + 60000).apply()
            Toast.makeText(this, "Learning for 60 s – open the app and scroll", Toast.LENGTH_LONG).show()
        })
        root.addView(btn("Forget all learned surveys") {
            prefs.edit().remove("seen").apply()
        })
        root.addView(btn("Test notification") {
            if (Build.VERSION.SDK_INT >= 33)
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            Notifier.post(this, "New survey", "\$0.85 · 10 min (test)")
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
